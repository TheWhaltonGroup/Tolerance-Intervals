# R Tolerance Interval Procedures V1.0
#
# Requires installation of the tolerance library
library(tolerance)

# To include files in the command line version of R, use the source statement:
# source('C:/temp/TOLERANCELIMITS/R_DEVELOPMENT/R_ROUTINES_FINAL_02.txt')
# For Windows users notice that the file location description must use '/' NOT '\' seperators

# To include files in RStudio, you may use the Toolbar commands:
#  Code  ->  Source  ->  (find file in the RStudio dialog box)

################################################################################
# K.two.sided - restating K.factor (from tolerance) with side=2 using 1 - alpha
#               given: n, proportion, one.minus.alpha
################################################################################
K.two.sided <- function(n, proportion, one.minus.alpha, method="EXACT", m=20) {

	K = K.factor(n=n, f=NULL, alpha=1-one.minus.alpha, P=proportion, 
                     side=2, method=method, m=m)

	results = c(n, proportion, one.minus.alpha, K )
	names(results) <- c("n", "proportion", "one.minus.alpha", "K two sided")
	return(results)
} # K.two.sided 
################################################################################

################################################################################
# K.one.sided - restating K.factor (from tolerance) with side = 1 using 1 - alpha
#               given: n, proportion, one.minus.alpha
################################################################################
K.one.sided <- function(n, proportion, one.minus.alpha, method="EXACT", m=20) {

	K = K.factor(n=n, f=NULL, alpha=1-one.minus.alpha, P=proportion, side=1, 
                     method=method, m=m)

	results = c(n, proportion, one.minus.alpha, K )
	names(results) <- c("n", "proportion", "one.minus.alpha", "K one sided")
	return(results)
} # K.one.sided 
################################################################################

################################################################################
# TI.two.sided - calculate two-sided tolerance limits using tolerance
#                given: n, x-bar, std.dev, proportion, one.minus.alpha
################################################################################
TI.two.sided <- function(n, x.bar, std.dev, proportion, one.minus.alpha, 
                         method="EXACT", m=20) {

	K = K.factor(n=n, f=NULL, alpha=1-one.minus.alpha, P=proportion, side=2, 
                     method=method, m=m)
	upper = x.bar + std.dev * K
	lower = x.bar - std.dev * K

	results = c(n, x.bar, std.dev, proportion, one.minus.alpha, lower, 
                    upper, K )
	names(results) <- c("n", "x.bar", "std.dev", "proportion", 
                            "one.minus.alpha", "2-sided.lower", "2-sided.upper",
                            "k")
	return(results)
} # TI.two.sided 
################################################################################

################################################################################
# TI.one.sided - calculate one-sided tolerance limits using tolerance
#                given: n, x.bar, std.dev, proportion, one.minus.alpha
################################################################################
TI.one.sided <- function(n, x.bar, std.dev, proportion, one.minus.alpha, method=
                         "EXACT", m=20) {

	K = K.factor(n=n, f=NULL, alpha=1-one.minus.alpha, P=proportion, side=1, 
                     method=method, m=m)
	upper = x.bar + std.dev * K
	lower = x.bar - std.dev * K

	results = c(n, x.bar, std.dev, proportion, one.minus.alpha, lower, 
                    upper, K )
	names(results) <- c("n", "x.bar", "std.dev", "proportion", 
                            "one.minus.alpha", "1-sided.lower", "1-sided.upper",
                            "K")
	return(results)
} # TI.one.sided 
################################################################################

################################################################################
# K.2.sided.app - calculate approximate two-sided K via one-sided K
#                 given: n, one.minus.alpha, p 
################################################################################
K.2.sided.app <- function(n, one.minus.alpha, p) {

	K = K.factor(n=n, alpha=(1-one.minus.alpha)/2, P=1-(1-p)/2, side=1)

	results =c(n, one.minus.alpha, p, K)

	names(results) <- c("n", "one.minus.alpha", "p", "K")
	return(results)

} # K.2.sided.app
################################################################################

################################################################################
# SEARCH FOR PROPORTION - 2-SIDED
# TI.2.sided.p - calculate approximate two-sided TI's via one-sided 
#                            TIs with fixed alpha, solve for p
#                            given: n, x.bar, std.dev, lower.limit, upper.limit, 
#                                   one.minus.alpha 
#  
################################################################################
TI.2.sided.p <- function(n, x.bar, std.dev, lower.limit, upper.limit, one.minus.alpha, digits=6, iterations=30) {

	k.target.upper = (upper.limit - x.bar) / std.dev
	k.target.lower = (x.bar -  lower.limit) / std.dev

	p.lower = 0.000001
	p.upper = 0.999999
	proportion = 0.5

	alpha = 1 - one.minus.alpha

	k2.upper = K.factor(n=n, f=NULL, alpha=alpha/2, P=proportion, side=1)
	i = 1

	while ( (signif(p.lower, digits = digits) != signif(p.upper, digits = digits)) & (i <= iterations) )    {
		k2.upper = K.factor(n=n, f=NULL, alpha=alpha/2, P=proportion, side=1)
		if (k2.upper < k.target.upper) {
			p.lower = proportion
			proportion = p.upper - (p.upper - p.lower) / 2
		} 
		else {
			p.upper = proportion
			proportion = p.lower + (p.upper - p.lower) / 2
		}
		i = i + 1
	}
	proportion.upper = proportion

	p.lower = 0.000001
	p.upper = 0.999999
	proportion = 0.5

	k2.lower = K.factor(n=n, f=NULL, alpha=alpha/2, P=proportion, side=1)
	i = 1

	while ( (signif(p.lower, digits = digits) != signif(p.upper, digits = digits)) & (i <= iterations) )    {
		k2.lower = K.factor(n=n, f=NULL, alpha=alpha/2, P=proportion, side=1)
		if (k2.lower < k.target.lower) {
			p.lower = proportion
			proportion = p.upper - (p.upper - p.lower) / 2
		} 
		else {
			p.upper = proportion
			proportion = p.lower + (p.upper - p.lower) / 2
		}
	 
		i = i + 1
	}
	proportion.lower = proportion
	p.overall  = 1 - ((1 - proportion.upper) + (1 - proportion.lower) )

	results =c(n, x.bar, std.dev,  lower.limit, upper.limit, one.minus.alpha, proportion.lower, proportion.upper, p.overall    )

	names(results) <- c("n", "x.bar", "std.dev",  "lower.limit", "upper.limit", "one.minus.alpha", "proportion.lower", "proportion.upper", "p.overall")
	return(results)

} # TI.2.sided.p

################################################################################
# SEARCH FOR ALPHA - 2-SIDED
# TI.2.sided.alpha - calculate approximate two-sided TI's via one-sided 
#                            TIs with fixed alpha, solve for p
#                            given: n, x.bar, std.dev, lower.limit, upper.limit, 
#                                   p 
#  
################################################################################
TI.2.sided.alpha <- function(n, x.bar, std.dev, lower.limit, upper.limit, proportion, digits=6, iterations=30) {

	k.target.upper = (upper.limit - x.bar) / std.dev
	k.target.lower = (x.bar - lower.limit) / std.dev

	a.lower = 0.000001
	a.upper = 0.999999
	alpha = (a.upper + a.lower)/2

	k2.upper = K.factor(n=n, f=NULL, alpha=alpha, P= (1 + proportion) / 2 , side=1, method="HE")
	i = 1

 	while ( (signif(a.lower, digits = digits) != signif(a.upper, digits = digits)) & (i <= iterations) )    {
		k2.upper = K.factor(n=n, f=NULL, alpha=alpha, P= (1 + proportion) / 2 , side=1, method="HE")
		if (k2.upper > k.target.upper) {
			a.lower = alpha
			alpha = a.upper - (a.upper - a.lower) / 2
		} 
		else {
			a.upper = alpha
			alpha = a.lower + (a.upper - a.lower) / 2
		}
		i = i + 1
	}

	alpha.upper = alpha

	a.lower = 0.000001
	a.upper = 0.999999
	alpha = (a.upper + a.lower)/2

	k2.lower = K.factor(n=n, f=NULL, alpha=alpha, P= (1 + proportion) / 2 , side=1, method="HE")
	i = 1

 	while ( (signif(a.lower, digits = digits) != signif(a.upper, digits = digits)) & (i <= iterations) )    {
		k2.lower = K.factor(n=n, f=NULL, alpha=alpha, P = (1 + proportion) / 2 , side=1, method="HE")
		if (k2.lower > k.target.lower) {
			a.lower = alpha
			alpha = a.upper - (a.upper - a.lower) / 2
		} 
		else {
			a.upper = alpha
			alpha = a.lower + (a.upper - a.lower) / 2
		}
	 
		i = i + 1
	}

	alpha.lower = alpha
	alpha.overall = 1 - (1 - alpha.lower - alpha.upper)  

	results =c(n, x.bar, std.dev, lower.limit, upper.limit, proportion, 1-alpha.lower, 1-alpha.upper, 1-alpha.overall )

	names(results) <- c("n", "x.bar", "std.dev", "lower.limit", "upper.limit", "proportion", "one.minus.alpha.lower", "one.minus.alpha.upper", "one.minus.alpha.overall")
	return(results)

} # TI.2.sided.alpha

################################################################################
# SEARCH FOR N - 2-SIDED
# TI.2.sided.n - calculate approximate two-sided TI's via one-sided 
#                            TIs with fixed alpha, solve for p
#                            given:   x.bar, std.dev, lower.limit, upper.limit, 
#                                   p , alpha
#  
################################################################################
TI.2.sided.n <- function(x.bar, std.dev, lower.limit, upper.limit, proportion, one.minus.alpha, digits=6, iterations=50) {

	k.target.upper = (upper.limit - x.bar) / std.dev
	k.target.lower = (x.bar - lower.limit) / std.dev

	n.lower = 2
	n.upper = 100000
	n.nominal = (n.upper + n.lower)/2

	alpha = 1 - one.minus.alpha

	k2.upper = K.factor(n=n.nominal, f=NULL, alpha=alpha/2, P= (1 + proportion)/2 , side=1, method="HE")
	i = 1

 	while ( (signif(n.lower, digits = digits) != signif(n.upper, digits = digits)) & (i <= iterations) )    {
		k2.upper = K.factor(n=n.nominal, f=NULL, alpha=alpha/2, P= (1 + proportion) / 2 , side=1, method="HE")
		if (k2.upper > k.target.upper) {
			n.lower = n.nominal
			n.nominal = n.upper - (n.upper - n.lower) / 2
		} 
		else {
			n.upper = n.nominal
			n.nominal = n.lower + (n.upper - n.lower) / 2
		}
		i = i + 1
	}
	n.upper.final = n.nominal

	n.lower = 2
	n.upper = 100000
	n.nominal = (n.upper + n.lower)/2

	k2.lower = K.factor(n=n.nominal, f=NULL, alpha=alpha/2, P= (1 + proportion)/2 , side=1, method="HE")
	i = 1

	while ( (signif(n.lower, digits = digits) != signif(n.upper, digits = digits)) & (i <= iterations) )    {
		k2.lower = K.factor(n=n.nominal, f=NULL, alpha=alpha/2, P= (1 + proportion) / 2 , side=1, method="HE")
		if (k2.lower > k.target.lower) {
			n.lower = n.nominal
			n.nominal = n.upper - (n.upper - n.lower) / 2
		} 
		else {
			n.upper = n.nominal
			n.nominal = n.lower + (n.upper - n.lower) / 2
		}
	 
		i = i + 1
	}

	n.lower.final = n.nominal

	n.final = max(n.lower.final , n.upper.final)     

	results =c(x.bar, std.dev, lower.limit, upper.limit, proportion, one.minus.alpha, n.lower.final, n.upper.final, n.final)

	names(results) <- c("x.bar", "std.dev", "lower.limit", "upper.limit", "proportion", "one.minus.alpha", "n.lower.final", "n.upper.final", "n.final")
	return(results)

} # TI.2.sided.n

################################################################################
# SEARCH FOR PROPORTION - 1-SIDED
# TI.1.sided.p - calculate 1-sided TI's via one-sided 
#                            TIs with fixed alpha, solve for p
#                            given: n, x.bar, std.dev, limit, one.minus.alpha 
#  
################################################################################
TI.1.sided.p <- function(n, x.bar, std.dev, limit, one.minus.alpha, digits=6, iterations=50) {
	library(tolerance)

	k.target = (limit - x.bar) / std.dev

	p.lower = 0.000001
	p.upper = 0.999999
	proportion = 0.5

	alpha = 1 - one.minus.alpha

	k1 = K.factor(n=n, f=NULL, alpha=alpha, P=proportion, side=1)
	i = 1

	while ( (signif(p.lower, digits = digits) != signif(p.upper, digits = digits)) & (i <= iterations) )    {
		k1 = K.factor(n=n, f=NULL, alpha=alpha, P=proportion, side=1)
		if (k1 < k.target) {
			p.lower = proportion
			proportion = p.upper - (p.upper - p.lower) / 2
		} 
		else {
			p.upper = proportion
			proportion = p.lower + (p.upper - p.lower) / 2
		}
		i = i + 1
	}

	lower = x.bar - k1 * std.dev
	upper = x.bar + k1 * std.dev

	results = c(n, x.bar, std.dev, proportion, one.minus.alpha, lower, 
                    upper, k1 )
	
	names(results) <- c("n", "x.bar", "std.dev", "proportion", 
                            "one.minus.alpha", "1-sided.lower", "1-sided.upper",
                            "K")
	return(results)

} # TI.1.sided.p

################################################################################
# SEARCH FOR ALPHA - 1-SIDED
# TI.1.sided.alpha - calculate 1-sided TI's   
#                            TIs with fixed propportion, solve for alpha
#                            given: n, x.bar, std.dev, limit, p   
#  
################################################################################
TI.1.sided.alpha <- function(n, x.bar, std.dev, limit, proportion, digits=6, iterations=50) {

	k.target = (limit - x.bar) / std.dev

	a.lower = 0.000001
	a.upper = 0.999999
	alpha = (a.upper + a.lower)/2

	k1 = K.factor(n=n, f=NULL, alpha=alpha, P= proportion, side=1, method="HE")
	i = 1

 	while ( (signif(a.lower, digits = digits) != signif(a.upper, digits = digits)) & (i <= iterations) )    {
		k1 = K.factor(n=n, f=NULL, alpha=alpha, P= proportion, side=1, method="HE")
		if (k1 > k.target) {
			a.lower = alpha
			alpha = a.upper - (a.upper - a.lower) / 2
		} 
		else {
			a.upper = alpha
			alpha = a.lower + (a.upper - a.lower) / 2
		}
		i = i + 1
	}

	one.minus.alpha = 1 - alpha

	lower = x.bar - k1 * std.dev
	upper = x.bar + k1 * std.dev

	results = c(n, x.bar, std.dev, proportion, one.minus.alpha, lower, 
                    upper, k1 )
	
	names(results) <- c("n", "x.bar", "std.dev", "proportion", 
                            "one.minus.alpha", "1-sided.lower", "1-sided.upper",
                            "K")
	return(results)

} # TI.1.sided.alpha

################################################################################
# SEARCH FOR N - 1-SIDED
# TI.2.sided.n - calculate 1-sided TI's via one-sided 
#                            TIs with fixed alpha, fixed p,  solve for n
#                            given:   x.bar, std.dev, lower.limit, upper.limit, 
#                                     p , alpha
#   
################################################################################
TI.1.sided.n <- function(x.bar, std.dev, limit, proportion, one.minus.alpha, digits=6, iterations=50) {

	k.target = (limit - x.bar) / std.dev
	#k.target.lower = (x.bar - lower.limit) / std.dev

	n.lower = 2
	n.upper = 100000
	n.nominal = (n.upper + n.lower)/2

	alpha = 1 - one.minus.alpha

	k1 = K.factor(n=n.nominal, f=NULL, alpha=alpha, P= proportion, side=1, method="HE")
	i = 1

 	while ( (signif(n.lower, digits = digits) != signif(n.upper, digits = digits)) & (i <= iterations) )    {
		k1 = K.factor(n=n.nominal, f=NULL, alpha=alpha, P= proportion, side=1, method="HE")
		if (k1 > k.target) {
			n.lower = n.nominal
			n.nominal = n.upper - (n.upper - n.lower) / 2
		} 
		else {
			n.upper = n.nominal
			n.nominal = n.lower + (n.upper - n.lower) / 2
		}
		i = i + 1
	}

	lower = x.bar - k1 * std.dev
	upper = x.bar + k1 * std.dev

	results = c(n.nominal, x.bar, std.dev, proportion, one.minus.alpha, lower, 
                    upper, k1 )
	
	names(results) <- c("n", "x.bar", "std.dev", "proportion", 
                            "one.minus.alpha", "1-sided.lower", "1-sided.upper",
                            "K")
	return(results)

} # TI.1.sided.n

#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
#############################################################################################################################
